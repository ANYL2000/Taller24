<?php
//procedimiento para generar las constancias por medio de ajax
require_once '../assets/conexion/servidor.php';

session_start();// Iniciando Sesion


if(!isset($_SESSION['login_user_sys'])){

  //mysqli_close($conexion); // Cerrando la conexion
  echo "<script type='text/javascript'>
        window.location='sesion.php'
        </script>"; // Redirecciona a la pagina de sesion
  }else{
  $usuario = $_SESSION['login_user_sys'];
  
  if($usuario!='Administrador'){
    session_destroy();
    echo "<script type='text/javascript'>
        window.location='sesion.php'
        </script>";
  
  }
  
  }


$conexion = connect($host, $port, $db_name, $db_username, $db_password);
$con=mysqli_connect($host,$db_username,$db_password,$db_name);
//$conexion->query("SET NAMES 'utf8'");

//obtener la fecha
date_default_timezone_set('America/Mexico_City');   

$año = date('Y');
$mes = date('m');



if($mes>=1&&$mes<=6){
  $año.="A";
 
  $fecha = "Enero-Junio";
 
}else if($mes>=7&&$mes<=12){
  $año.="B";
 
  $fecha = "Julio-Diciembre";
 

}



$folio1 = "SELECT * FROM folio_constancias";
$filas_folio1 = mysqli_query($con,$folio1);

//si encontro el folio entra al if
if(mysqli_num_rows($filas_folio1)>0){
    while($informacion_folio1 = mysqli_fetch_array($filas_folio1)){
      $ciclo_folio1 = $informacion_folio1['Folio_ciclo'];
      // $numero_folio1 = $informacion_folio1['Folio_numero']; //se guarda el numero de folio en una variable
    }

   
    if(strcmp($año,$ciclo_folio1)!=0){

      $conexion->query("DELETE FROM folio_constancias");  //se borra lo que hay en tabla de folios
      
    }

  }
//echo $fecha;

//convertir vector en string
$vector = $_POST['array'];
$resultado = implode(",", $vector);
$r = explode(",", $resultado);

//algoritmo para insertar los alumnos a la tabla de constancias



$id = "";
$numero_nuevo_ConCeros="";
$num="";
//echo $r[0];

for($i=0;$i<count($r);$i++){

    
    $id = $r[$i];
   
$usuario = "SELECT * FROM usuarios_talleres WHERE idUsuarios= '$id' ";
$filas_usuario = mysqli_query($con,$usuario);



while($informacion_usuario = mysqli_fetch_array($filas_usuario)){

  $codigo = $informacion_usuario['Codigo'];
  $tallerista = $informacion_usuario['NombreTallerista'];
    $taller = $informacion_usuario['NombreTaller'];
    $ingreso = $informacion_usuario['Ingreso'];
    $turno = $informacion_usuario['Turno'];
    $dia = $informacion_usuario['Dia'];

  $usuario_con_constancia = "SELECT * FROM constancias_alumnos WHERE Codigo= '$codigo' AND NombreTallerista='$tallerista'
  AND NombreTaller='$taller' AND Ingreso='$ingreso' AND Turno='$turno' AND Dia='$dia'";

$constancia_generada_usuario = mysqli_query($con,$usuario_con_constancia);


  if(mysqli_num_rows($constancia_generada_usuario)==0){

    $folio = "SELECT * FROM folio_constancias";
    $filas_folio = mysqli_query($con,$folio);
    
    //si encontro el folio entra al if
    if(mysqli_num_rows($filas_folio)>0){
        while($informacion_folio = mysqli_fetch_array($filas_folio)){
          $ciclo_folio = $informacion_folio['Folio_ciclo'];
           $numero_folio = $informacion_folio['Folio_numero']; //se guarda el numero de folio en una variable
        }
        $numero_folio++;
      //  $conexion->query("DELETE FROM folio_constancias");  //se borra lo que hay en tabla de folios
       // $numero_folio++; //se suma 1 al numero de folio
      
    
    }else{
      //si es el primer folio se iguala a 1 para empezar con el conteo
        $numero_folio=1;
    }





    $nombre = $informacion_usuario['Nombre'];
    $correo = $informacion_usuario['Correo'];
    $carrera = $informacion_usuario['Carrera'];
    

    $numero_folio_nuevo = $numero_folio;

    switch(strlen($numero_folio_nuevo)){

      case 1:  $numero_nuevo_ConCeros = str_pad($num, 3, "0", STR_PAD_LEFT);$numero_nuevo_ConCeros.=$numero_folio_nuevo; break;
    
       case 2: $numero_nuevo_ConCeros = str_pad($num, 2, "0", STR_PAD_LEFT); $numero_nuevo_ConCeros.=$numero_folio_nuevo; break;
    
       case 3: $numero_nuevo_ConCeros = str_pad($num, 1, "0", STR_PAD_LEFT); $numero_nuevo_ConCeros.=$numero_folio_nuevo; break;
    
       default: $numero_nuevo_ConCeros = $numero_folio_nuevo; break;
    }
   

      $folio_completo = $año.'-'.$numero_nuevo_ConCeros;


    $conexion->query("INSERT INTO constancias_alumnos (Folio,Codigo,Nombre,Correo,Carrera,NombreTallerista,NombreTaller,Ingreso,Turno,Dia) values ('$folio_completo','$codigo','$nombre','$correo','$carrera','$tallerista','$taller','$ingreso','$turno','$dia')");

    $conexion->query("DELETE FROM folio_constancias");  //se borra lo que hay en tabla de folios

    $conexion->query("INSERT INTO folio_constancias (Folio_ciclo,Folio_numero) values ('$año',$numero_nuevo_ConCeros)");

  }
}

}




//echo $resultado.'---'.$r[19].'----'.count($r);
$con->close();
$conexion = null;


?>