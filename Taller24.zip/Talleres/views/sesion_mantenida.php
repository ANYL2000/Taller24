<?php
require_once '../assets/conexion/servidor.php';
$conexion->query("SET NAMES 'utf8'");
$conexion=mysqli_connect($host,$db_username,$db_password,$db_name);


session_start();// Iniciando Sesion
// Guardando la sesion
$user_check = $_SESSION['login_user_sys'];
// SQL Query para completar la informacion del usuario
$ses_sql="SELECT Usuario FROM cuentas_usuarios WHERE Usuario='$user_check'";

$login_session = mysqli_query($conexion,$ses_sql);


if(mysqli_num_rows($login_session)==0){
mysqli_close($conexion); // Cerrando la conexion
echo "<script type='text/javascript'>
      window.location='sesion.php'
      </script>"; // Redirecciona a la pagina de sesion
}
?>