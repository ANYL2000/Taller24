<?php

//include('sesion_mantenida.php');
require_once '../assets/conexion/servidor.php';

session_start();// Iniciando Sesion



if(!isset($_SESSION['login_user_sys'])){

//mysqli_close($conexion); // Cerrando la conexion
echo "<script type='text/javascript'>
      window.location='sesion.php'
      </script>"; // Redirecciona a la pagina de sesion
}else{
$usuario = $_SESSION['login_user_sys'];

if($usuario!='Administrador'){
  session_destroy();
  echo "<script type='text/javascript'>
      window.location='sesion.php'
      </script>";

}

}


$conexion->query("SET NAMES 'utf8'");
$conexion = connect($host, $port, $db_name, $db_username, $db_password);
$con=mysqli_connect($host,$db_username,$db_password,$db_name);

date_default_timezone_set('America/Mexico_City');   

$año = date('Y');
$mes = date('m');



if($mes>=1&&$mes<=6){
  $año.="A";
 
  $fecha = "Enero-Junio";
 


}else if($mes>=7&&$mes<=12){
  $año.="B";
 
  $fecha = "Julio-Diciembre";
 
 

}else if($mes>12||$mes<1){

  echo "<script>alert('Configure correctamente su zona horaria');</script>";
  echo "<script>window.location='taller1.1.php';</script>";
}

//idTalleres,NombreTallerista,NombreTaller, Calendario, Capacidad, Turno, Tipo,Dia,Registrados,Lugares_Faltantes

//session_start();
// Establecer tiempo de vida de la sesión en segundos
$inactividad = 300;


$query =$conexion->prepare("SELECT * FROM mostrar_talleres WHERE Calendario='$año';");

$query->execute();
$resultado =$query->fetchAll();

 //consultar cuenta prestador
 $cuenta_prestador =$conexion->prepare("SELECT * FROM cuentas_usuarios WHERE Usuario='Prestador'");

 $cuenta_prestador->execute();
 $resultado_cuenta_prestador =$cuenta_prestador->fetchAll();
 
 foreach($resultado_cuenta_prestador as $cuenta_usuario_prestador):
 $contra_prestador = $cuenta_usuario_prestador['Contra'];
 endforeach;

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

<header>
    <title>Talleres</title>
</header>


<link rel="stylesheet" href="../assets/css/estilo_taller1.1.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">

<?php include 'header_taller.php'; ?>

<div class="btn-group justify-content-right" style="position:relative;margin-left:3vw;top:-5vh;">
<button type="button" class="btn btn-light dropdown-toggle" data-toggle="dropdown"><?php echo $_SESSION['login_user_sys']; ?><span class="caret"></span></button>
<ul class="dropdown-menu" role="menu">
<li><a href="cerrar_sesion.php">Cerrar sesión</a></li>

</ul>
</div>

</head>
<body>
    
<div id="modal_tiempo_excedido">

</div>


<div class="fondo">




<a class="btn btn-primary nuevo" href="taller1.php">Registrar Nuevo Taller</a>



<button type='submit' class='btn btn-secondary cuentas' id='cuentas' name='cuentas' data-toggle='modal' data-target="#cuentasModal">Cuentas de usuarios</button>

<h1 class="titulo_taller">Talleres registrados</h1>

<table class="table-responsive">
    <thead>
<tr class="fila_principal">

    <td>Nombre del taller</td>
    <td>Calendario</td>
    <td>Capacidad</td>
    <td>Turno</td>
    <td>Tipo</td>
    <td>Dia</td>
    <td>Registrados</td>
    <td>Faltantes</td>
</tr>
</thead>
<?php  foreach($resultado as $taller):  ?>

    <!--taller1.2.php?idtaller='<?php //echo $taller['NombreTaller']?>'-->
   

<tr class="filas_secundarias" id="color_filas" >

    <td> <a href="taller1.2.php?tallerista=<?php echo utf8_encode($taller['NombreTallerista'])?>&taller=<?php echo utf8_encode($taller['NombreTaller'])?>&calendario=<?php echo $taller['Calendario']?>&turno=<?php echo $taller['Turno']?>&dia=<?php echo $taller['Dia']?>"> <?php echo utf8_encode($taller['NombreTaller']);?> </a></td>
    <td> <a href="taller1.2.php?tallerista=<?php echo utf8_encode($taller['NombreTallerista'])?>&taller=<?php echo utf8_encode($taller['NombreTaller'])?>&calendario=<?php echo $taller['Calendario']?>&turno=<?php echo $taller['Turno']?>&dia=<?php echo $taller['Dia']?>"> <?php echo utf8_encode($taller['Calendario']);?></a></td>
    <td><a href="taller1.2.php?tallerista=<?php echo utf8_encode($taller['NombreTallerista'])?>&taller=<?php echo utf8_encode($taller['NombreTaller'])?>&calendario=<?php echo $taller['Calendario']?>&turno=<?php echo $taller['Turno']?>&dia=<?php echo $taller['Dia']?>"><?php echo $taller['Capacidad']?></a></td>
    <td><a href="taller1.2.php?tallerista=<?php echo utf8_encode($taller['NombreTallerista'])?>&taller=<?php echo utf8_encode($taller['NombreTaller'])?>&calendario=<?php echo $taller['Calendario']?>&turno=<?php echo $taller['Turno']?>&dia=<?php echo $taller['Dia']?>"><?php echo $taller['Turno']?></a></td>
    <td><a href="taller1.2.php?tallerista=<?php echo utf8_encode($taller['NombreTallerista'])?>&taller=<?php echo utf8_encode($taller['NombreTaller'])?>&calendario=<?php echo $taller['Calendario']?>&turno=<?php echo $taller['Turno']?>&dia=<?php echo $taller['Dia']?>"><?php echo $taller['Tipo']?></a></td>
    <td><a href="taller1.2.php?tallerista=<?php echo utf8_encode($taller['NombreTallerista'])?>&taller=<?php echo utf8_encode($taller['NombreTaller'])?>&calendario=<?php echo $taller['Calendario']?>&turno=<?php echo $taller['Turno']?>&dia=<?php echo $taller['Dia']?>"><?php echo $taller['Dia']?></a></td>
    <td><a href="taller1.2.php?tallerista=<?php echo utf8_encode($taller['NombreTallerista'])?>&taller=<?php echo utf8_encode($taller['NombreTaller'])?>&calendario=<?php echo $taller['Calendario']?>&turno=<?php echo $taller['Turno']?>&dia=<?php echo $taller['Dia']?>"><?php echo $taller['Registrados']?></a></td>
    <td><a href="taller1.2.php?tallerista=<?php echo utf8_encode($taller['NombreTallerista'])?>&taller=<?php echo utf8_encode($taller['NombreTaller'])?>&calendario=<?php echo $taller['Calendario']?>&turno=<?php echo $taller['Turno']?>&dia=<?php echo $taller['Dia']?>"><?php echo $taller['Lugares_Faltantes']?></a></td>
</tr>
</a>

<?php   endforeach; ?>

</table>


<!--Seccion del modal de la informacion de las cuentas-->

<!-- Modal Cuentas-->
<div class="modal fade" id="cuentasModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Cuentas de usuarios</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="taller1.1.php" method="POST"> <!--fa-solid fa-pencil-slash-->
       
         
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Administrador</label>
            <div class="input-group">
      <input id="recipient_contra_admin" name = "recipient_contra_admin"  type="Password" Class="form-control" disabled placeholder="Escribe la nueva contraseña aqui">
      <div class="input-group-append">
            <button id="show_password" class="btn btn-primary" type="button" onclick="mostrarPasswordAdmin()" > <span class="fa fa-eye-slash icon_admin"></span> </button>
            <button type="button" class="btn btn-light editar_contra_admin" id="editar_contra_admin" name="editar_contra_admin" onclick="editar_campos_admin()"><span class="fa fa-pencil edit"></span></button>
          </div>
    </div>
            <!--<input type="text" class="form-control" id="recipient_contra_admin"  name = "recipient_contra_admin" value="<?php //echo $fila["Nombre"]; ?>" required autocomplete="off">-->

          </div>
          <div class="form-group">
                   <label for="recipient-name" class="col-form-label">Prestador</label>
          
                   <div class="input-group">
                 <input id="recipient_contra_prestador" name = "recipient_contra_prestador"  type="Password" Class="form-control" disabled placeholder="Escribe la nueva contraseña aqui">
                <div class="input-group-append">
               <button id="show_password2" class="btn btn-primary" type="button" onclick="mostrarPasswordPrestador()" > <span class="fa fa-eye-slash icon_prestador"></span> </button>
               <button type="button" class="btn btn-light editar_contra_prestador" id="editar_contra_prestador" name="editar_contra_prestador" onclick="editar_campos_prestador()"><span class="fa fa-pencil edit"></span></button>
              </div>
              </div>
          </div>
         
        
          <div class="modal-footer"> 
        <button type="submit" class="btn btn-secondary"  data-dismiss="modal">Cerrar</button>
        <button type="submit" class="btn btn-primary guardar_cambios" id="btncuentas" name="btncuentas" hidden="true">Guardar cambios</button>
      </div>
        </form>
      </div>
      
    </div>
  </div>
</div>




</div>

<!--Habilitar campos y mostrar texto de los inputs del modal de las cuentas de usuario-->
<script type="text/javascript">
function mostrarPasswordAdmin(){
		var cambio = document.getElementById("recipient_contra_admin");
		if(cambio.type == "password"){
			cambio.type = "text";
			$('.icon_admin').removeClass('fa fa-eye-slash').addClass('fa fa-eye');
		}else{
			cambio.type = "password";
			$('.icon_admin').removeClass('fa fa-eye').addClass('fa fa-eye-slash');
		}
	} 

  function mostrarPasswordPrestador(){
		var cambio = document.getElementById("recipient_contra_prestador");
		if(cambio.type == "password"){
			cambio.type = "text";
			$('.icon_prestador').removeClass('fa fa-eye-slash').addClass('fa fa-eye');
		}else{
			cambio.type = "password";
			$('.icon_prestador').removeClass('fa fa-eye').addClass('fa fa-eye-slash');
		}
	} 
	
  function editar_campos_admin(){
    var cambio1 = document.getElementById("recipient_contra_admin");
    var cambio2 = document.getElementById("recipient_contra_prestador");
    var cambio3_boton = document.getElementById("btncuentas");
    if(cambio1.disabled == true ){

      cambio3_boton.hidden = false;
			cambio1.disabled = false;
     
			$('.editar_contra_admin').removeClass('btn btn-light').addClass('btn btn-dark');
		}else{
      if(cambio2.disabled == true){
      cambio3_boton.hidden = true;
      }
      cambio1.disabled = true;
     
      $('.editar_contra_admin').removeClass('btn btn-dark').addClass('btn btn-light');
		}
  }

  function editar_campos_prestador(){
    var cambio1 = document.getElementById("recipient_contra_admin");
    var cambio2 = document.getElementById("recipient_contra_prestador");
    var cambio3_boton = document.getElementById("btncuentas");
    if(cambio2.disabled == true){
      cambio3_boton.hidden = false;
      cambio2.disabled = false;
			$('.editar_contra_prestador').removeClass('btn btn-light').addClass('btn btn-dark');
		}else{
      if(cambio1.disabled == true){
      cambio3_boton.hidden = true;
      }
      cambio2.disabled = true;
      $('.editar_contra_prestador').removeClass('btn btn-dark').addClass('btn btn-light');
		}

  }

</script>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="../assets/js/sweetalert.js"></script>
<?php

if(isset($_POST['btncuentas'])){

  $admin_contra = $_POST['recipient_contra_admin'];

  $admin_contra_encrypt = sha1($_POST['recipient_contra_admin']);
  $prestador_contra = $_POST['recipient_contra_prestador'];
  
  $validar_contraseñas = "SELECT * FROM cuentas_usuarios";

  $contraseñas = mysqli_query($con,$validar_contraseñas);

 


 
  
  
 if($admin_contra!=$prestador_contra){

 

  $i=0;
  while($filas_cuenta = mysqli_fetch_array($contraseñas)){
    
    $user[$i] = $filas_cuenta['Usuario'];
   $password[$i] = $filas_cuenta['Contra'];
   
   $i++;
  }

  if(!empty($admin_contra)){ //entra si se agrega una contraseña de administrador 

if($admin_contra_encrypt!=$password[0]){//if para saber si la contraseña del administrador es diferente al de la base de datos

  $con->query("UPDATE cuentas_usuarios SET Contra = '$admin_contra_encrypt' WHERE Usuario= '$user[0]'");

  if(!empty($prestador_contra)){ 
    $con->query("UPDATE cuentas_usuarios SET Contra = '$prestador_contra' WHERE Usuario= '$user[1]'");
  }

  if($con){ //se muestra la ventana de exito al actualizar las contraseñas
    echo '<script>alertaNoti("Se han actualizado los datos con exito")</script>';
  }


}else{ //else que muestra un error de que la contraseña de administrador es la misma que la base de datos y no ha cambiado
  
  echo '<script>alertaeNoti("Esta contraseña de administrador es la que esta asignada actualmente")</script>';
}


  }


  if(!empty($prestador_contra)){ 
  if($prestador_contra!=$password[1]){ //if para saber si la contraseña del prestador es diferente al de la base de datos

    $con->query("UPDATE cuentas_usuarios SET Contra = '$prestador_contra' WHERE Usuario= '$user[1]'");
    if($con){ //se muestra la ventana de exito al actualizar las contraseñas
      echo '<script>alertaNoti("Se han actualizado los datos con exito")</script>';
    }
  }

  }
   /* echo "<script type='text/javascript'>
    setTimeout(refrescar,3000);

    funtion refrescar(){
      window.location='taller1.php';
    }
        </script>";*/


 }else{  //else para mostrar error de contraseñas iguales
  echo '<script>alertaeNoti("Las contraseñas no deben ser iguales entre usuarios")</script>';
 }


 



}

?>

<script
      src="https://code.jquery.com/jquery-3.6.0.min.js"
      integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4="
      crossorigin="anonymous"
    ></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
<!--<script src="../assets/js/jquery-3.6.0.min.js"></script>-->

<?php
//Comprobar si $_SESSION["timeout"] está establecida
/*if(isset($_SESSION["timeout"])){
  // Calcular el tiempo de vida de la sesión (TTL = Time To Live)
  $sessionTTL = time() - $_SESSION["timeout"];
  if($sessionTTL > $inactividad){
      session_destroy();
      echo "<script> 

      $.ajax({
        url: 'tiempo_excedido_modal.php',
      type: 'POST',
      dataType: 'html',
      //data: {buscar: buscar},
      
      })
      .done(function(respuesta){
        $('#modal_tiempo_excedido').html(respuesta);
      })
      .fail(function(){
      
      })
      
      </script>";
     
      echo "<script type='text/javascript'>
      window.location='sesion.php'
      </script>";
  }
}*/
?>

</body>
</html>
<?php $con->close();  $conexion = null;?>